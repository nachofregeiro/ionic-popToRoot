import { NavController } from 'ionic-angular';

export class BasePage {

  constructor(protected nav: NavController) {
  }

  handleError(error: any) {
    if (error.status == 401) {
      this.handleUnauthorized();
    }
  }

  handleUnauthorized() {
    console.log("Unauthorized");
    this.nav.popToRoot();
  }
}