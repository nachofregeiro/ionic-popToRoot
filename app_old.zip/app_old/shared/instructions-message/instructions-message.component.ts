import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'instructions-message',
  templateUrl: 'build/shared/instructions-message/instructions-message.html'
})
export class InstrucionsMessageComponent implements OnInit {
  @Input() showCloseButton: Boolean;

 showInstructions: boolean;

  ngOnInit(){
    this.showInstructions = true; 

    if(this.showCloseButton == undefined)
        this.showCloseButton = false; 
  }

  closeInstructions() {
    this.showInstructions = false;
  }
  
}