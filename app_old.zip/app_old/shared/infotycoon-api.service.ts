import { Config } from 'ionic-angular';
import { Injectable } from '@angular/core';  
import { Http, Response, Headers, HTTP_PROVIDERS } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { ItemsDetail, LookupDetails, ItemCommentsModel, ItemPhoto } from '../inspection/shared/index';
import { SettingsService } from '../config/index';
import { HttpRequest } from '../shared/index';
import { Property } from '../property/index';

@Injectable()
export class InfoTycoonApiService {
    private _url: string;
    public _inspectionId: number;
    public _unitId: number;
    public _unitExternalId: string;
    public _propertyExternalId: string;
    
    constructor(private _http: Http, private _settingsService: SettingsService) {
        // TODO: Use official Angular2 CORS support when merged (https://github.com/angular/angular/issues/4231).
        let _build = (<any> _http)._backend._browserXHR.build;
        (<any> _http)._backend._browserXHR.build = () => {
        let _xhr =  _build();
        _xhr.withCredentials = true;
        return _xhr;
        };      
    }
    
    getToken(username: string, password: string) {
        let data = "grant_type=password&username=" + username + "&password=" + password;
        let headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        return this._http.post(this.url('/Token'), data, {
            withCredentials: false,
            headers: headers
        });
    }

    logIn(username: string, password: string) {
        let headers = new Headers();
        return this._http.post(this.url('/api/Auth'), JSON.stringify({ username: username, password: password}), headers);
    }

    logOut() {
        this._http.delete(this.url('/api/Auth'));
    }
    
    getInteriorItems(): Observable<ItemsDetail>  {
        let url = this.url('/api/inspectionitems/GetInteriorItemsByCategory?inspectionId=' + this._inspectionId + '&unitId=' + this._unitId);
        return this._http.get(url).map(this.extractData);
    }

    getProperty(): Observable<Property>  {
        let url = this.url('/api/property/GetInspections/');
        let headers = new Headers(); 
        return this._http.post(url,{
            unitExternalId: this._unitExternalId, 
            propertyExternalId: this._propertyExternalId 
        }, headers)
                   .map(this.extractData);
    }


    updateInspectionInteriorItemComment(model : ItemCommentsModel): Observable<ItemsDetail>  {
        let url = this.url('/api/inspectionitems/UpdateInspectionInteriorItemComment');
        model.inspectionId = this._inspectionId;        
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }

    addInspectionInteriorItemComment(model : ItemCommentsModel): Observable<ItemsDetail>  {
        let url = this.url('/api/inspectionitems/AddInspectionInteriorItemComment');
        model.inspectionId = this._inspectionId;        
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }
    
    addInspectionPhoto(model : ItemPhoto): Observable<ItemPhoto>  {
        let url = this.url('/api/InspectionPhoto/AddInspectionPhoto');
        model.inspectionId = this._inspectionId;      
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }
    
    updateInspectionPhoto(model : ItemPhoto): Observable<ItemPhoto>  {
        let url = this.url('/api/InspectionPhoto/UpdateInspectionPhoto');
        model.inspectionId = this._inspectionId;      
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }
    
    removeInspectionPhoto(model : ItemPhoto): Observable<ItemPhoto>  {
        let url = this.url('/api/InspectionPhoto/RemoveInspectionPhoto');
        model.inspectionId = this._inspectionId;      
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }
    
    resetItem(itemId : number, actionTypeId: number) : any {
        let url = this.url('/api/inspectionitems/ResetInspectionInteriorItem');
        let model = {inspectionId: this._inspectionId, itemId: itemId, actionTypeId: actionTypeId};
        return this._http.post(url, JSON.stringify(model)).map(this.extractData);
    }
    
    lookup(lastUpdated?: string): Observable<LookupDetails> {
        let filter = (lastUpdated == null || lastUpdated == '') ?  '' : '?lastUpdated=' + lastUpdated;
        let url = this.url('/api/Lookup' + filter);
        return this._http.get(url).map(this.extractData);
    }
    
    private url(path: string) {
        return this._settingsService.apiUrl + path;
    }
    
    private extractData(res: Response) {        
        if (res.status < 200 || res.status >= 300) {
            let errMsg = `${res.status} - ${res.statusText}`;
            console.error(errMsg); 
            throw new Error(errMsg);            
        }
        
        let body;
         
        if (res.text()) {
            body = res.json();
        }

        return body || {};
    }   
    
    private handleError (error: any) {
        if (error.status < 200 || error.status >= 300) {
            let errMsg = (error.message) ? error.message :
                error.status ? `${error.status} - ${error.statusText}` : 'Server error';
            console.error(errMsg); 
            return Observable.throw(errMsg);
        }
        return error;
    }    
}