import {Pipe, PipeTransform} from '@angular/core';
import {DatePipe} from '@angular/common';

@Pipe({
  name: 'NullableDateTimePipe'
})
export class NullableDateTimePipe implements PipeTransform {
  transform(value, args:any[]) {
 
    if (value == null) return;

    var format = args ? args[0] : 'MM/dd/yyyy, HH:mm:ss';

    var date = new Date(value);
    var datePipe = new DatePipe();
    return datePipe.transform(date, format);

  }
}