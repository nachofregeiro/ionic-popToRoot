import { Component, Input, OnDestroy } from '@angular/core';

@Component({
  selector: 'check',
  templateUrl: 'build/shared/check/check.html'
})
export class CheckComponent {
    @Input() isChecked: boolean; 
}
