import { Injectable } from "@angular/core";
import { Http, Request, RequestOptionsArgs, Response, XHRBackend, RequestOptions, ConnectionBackend, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class HttpRequest extends Http {

    constructor(backend: ConnectionBackend, defaultOptions: RequestOptions) {
        super(backend, defaultOptions);
    }

    request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
        return super.request(url, options);        
    }

    get(url: string, options?: RequestOptionsArgs): Observable<Response> {
        options = this.appendHeader('X-Requested-With', 'XMLHttpRequest', options);
        return super.get(url, this.setDefaultOptions(options));
    }

    post(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {   
        options = this.appendHeader('Content-Type', 'application/json; charset=utf-8', options);
        return super.post(url, body, this.setDefaultOptions(options));
    }

    put(url: string, body: any, options?: RequestOptionsArgs): Observable<Response> {
        return super.put(url, body, this.setDefaultOptions(options));
    }

    delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
        return super.delete(url, this.setDefaultOptions(options));
    }
    
    appendHeader(name: string, value: string, options?: RequestOptionsArgs): RequestOptionsArgs {
        if (options == null) {
            options = new RequestOptions();
        }
        if (options.headers == null) {
            options.headers = new Headers();
        }
        if (options.headers.get(name) == null) {
            options.headers.append(name, value);
        }

        return options;
    }

    setDefaultOptions(options?: RequestOptionsArgs) : RequestOptionsArgs {
        var token_type = localStorage.getItem("token_type");
        var access_token = localStorage.getItem("access_token");
        
        if (token_type && access_token) {
            var authorization = token_type + " " + access_token;
            this.appendHeader('Authorization', authorization, options);
        }
        
        return options;
    }
}