import { Loading, LoadingController, NavController, NavParams } from 'ionic-angular';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { Component, OnInit } from '@angular/core';

import { ItemComponent } from './item/index';
import { BasePage, InfoTycoonApiService, Accordion, AccordionGroup, InstrucionsMessageComponent } from '../shared/index';
import { ItemsDetail, Item, InspectionItem, Category, InspectionCategory, MeasuringUnit } from './shared/index';

@Component({
  templateUrl: 'build/inspection/inspection.component.html',
  directives: [ItemComponent, Accordion, AccordionGroup,InstrucionsMessageComponent]
})
export class InspectionComponent implements OnInit {
  itemsDetail: ItemsDetail;
  measuringUnits: Array<MeasuringUnit>;
  unitName: string;
  inspectionId: number;
  unitId: number;
  loading: Loading;
  categoriesStatus: InspectionCategoryDisctionary;

  constructor(private nav: NavController,
              private _infoTycoonApiService: InfoTycoonApiService, 
              private loadingController: LoadingController) {
    //super(nav);
    this.unitName = '';
    this.categoriesStatus = {};
  }

  ngOnInit() {
    //this.showLoading();
    this.getInteriorItems();
  }

  getInteriorItems() {
    //this.loading.dismiss();
    setTimeout(() => {
      this.nav.popToRoot();
    }, 1000);

    // Observable.forkJoin(
    //   this._infoTycoonApiService.getInteriorItems(),
    //   this._infoTycoonApiService.lookup())
    //   .subscribe(data => {
    //     let interiorItemsData = data[0];
    //     let lookUpData = data[1];
    //     this.itemsDetail = interiorItemsData;
    //     this.unitName = interiorItemsData.unit.unitName;
    //     this.measuringUnits = lookUpData.measuringUnits;
    //     this.initCategories();
    //     this.loading.dismiss();
    //   }, error => {
    //     console.log("Get Interior Items has failed");
    //     this.loading.dismiss();
    //     this.handleError(error);
    //   });
  }

  handleError(error: any) {
    if (error.status == 401) {
      this.handleUnauthorized();
    }
  }

  handleUnauthorized() {
    console.log("Unauthorized");
    this.nav.popToRoot();
  }

  initCategories() {
    let categories = this.itemsDetail.categories;

    categories.forEach((c: Category, i: number) => {
      let inspectionCategory = new InspectionCategory(c);
      this.categoriesStatus[c.categoryName] = inspectionCategory;
    });
  }

  getCompletedPercentage() {
    let itemsCount: number = 0;
    let completedItemsCount: number = 0;
    let percent: number = 0;

    if (this.itemsDetail != undefined) {
      let categories = this.itemsDetail.categories;
      categories.forEach(c => {
        itemsCount += c.items.length;
        let inspectionCategory = new InspectionCategory(c);
        completedItemsCount += inspectionCategory.getCompletedItems();
      });
    }

    percent = (itemsCount > 0) ? completedItemsCount/itemsCount : 0;

    return percent;
  }

  showLoading() {
    this.loading = this.loadingController.create({
      content: "Please wait..."
    });
    this.loading.present();
  }

}

export interface IDictionary<T> {
  [key: string]: T;
};

export interface InspectionCategoryDisctionary extends IDictionary<InspectionCategory> { };