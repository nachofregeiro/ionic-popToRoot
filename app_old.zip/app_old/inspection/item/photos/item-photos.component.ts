import { Component, Input } from '@angular/core';
import { Camera } from 'ionic-native';
import { ViewController, NavParams, AlertController, ToastController, Loading, LoadingController } from 'ionic-angular';
import { InfoTycoonApiService, DateTimeService } from '../../../shared/index';
import { Item, Photo, ItemPhoto } from '../../shared/index';
import { SettingsService } from '../../../config/index';

@Component({
    templateUrl: 'build/inspection/item/photos/item-photos.component.html'
     
  })
export class ItemPhotosComponent {
  item: Item;
  isBrowser: boolean;
  selectedPhoto: Photo;
  addingCaption: boolean;
  newCaption: string;
  newBaseImage: string;
  isNewPhoto: boolean;
  loading: Loading; 
  dateTimeService: DateTimeService;
    
  constructor( private viewCtrl: ViewController, 
               private _settings: SettingsService, 
               private _infoTycoonApiService: InfoTycoonApiService,
               private _dateTimeService: DateTimeService,
               params: NavParams, 
               private alertController: AlertController,
               private loadingController: LoadingController,
               private toastController: ToastController) {
    this.item = params.get('item');
    this.isBrowser = _settings.isWebBrowser;
    this.dateTimeService = _dateTimeService;
  }
  
  done() {
    this.viewCtrl.dismiss();
  }
  
  pickPhoto(){
    this.addingCaption = true;
  }
  
  takePhoto(options = {}){
    Camera.getPicture(options).then(
      (imageData) => {
        let base64Image = "data:image/jpeg;base64," + imageData;
        this.selectedPhoto = this.createPhoto(base64Image); 
        this.addingCaption = true;
      }, 
      (err) => {
      }
    );    
  }
  
  fileSelected(input) {
    let reader = new FileReader();    
    
     reader.addEventListener("load", (event : any) => {  
              let base64Image = event.target.result;
              this.selectedPhoto = this.createPhoto(base64Image); 
              this.addingCaption = true; 
                          
            }, false);

            reader.readAsDataURL(input.files[0]);
  }
  
    
  createPhoto(data: string) : Photo{
        this.isNewPhoto = true;
        let photo = new Photo();
        let date = new Date();
        photo.thumbnailUrl = data;
        photo.imageData = data;
        photo.updatedBy = 'User';
        photo.updatedOn = date.toUTCString();
        return photo;
  }
  
   itemHasPhotos() {
    return this.item.photos.length != 0
  }
  
   deletePhoto(photo) {
    this.selectedPhoto = photo;
    let confirm = this.alertController.create({
      title: 'Delete Photo',
      message: 'Do you want to delete this photo?',
      buttons: [
        {
          text: 'OK',
          handler: () => {
              this.showLoading();
              let model = new ItemPhoto();
              model.itemId =  this.item.itemId;
              model.photo =  this.selectedPhoto;
              this._infoTycoonApiService.removeInspectionPhoto(model).subscribe(data => {
                this.removePhoto();
              this.showToast("Item Photo was removed succesfully");
              this.loading.destroy();
            }, error => {
              this.showToast("Something went wrong removed a Photo");
              this.loading.destroy();
            });
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Cancel delete photo');
          }
        }
      ]
    });
    confirm.present();
  }
  
  editCaption(photo) {
    this.isNewPhoto = false;
    this.selectedPhoto = photo;
    this.newCaption = photo.photoCaption;
    this.addingCaption = true;
  }
  
  addPhoto(){ 
      this.item.photos.push(this.selectedPhoto);
      this.item.photosCount = this.item.photosCount + 1;     
  }
  
  removePhoto(){ 
      var index = this.item.photos.indexOf(this.selectedPhoto);
      this.item.photos.splice(index, 1);
      this.item.photosCount = this.item.photosCount - 1;     
  }
  
  showLoading() {
    this.loading = this.loadingController.create({
      content: "Please wait..."
    });
    this.loading.present();
  }
  
  savePhoto(){ 
    this.showLoading();
    
    let model = new ItemPhoto();
    model.itemId =  this.item.itemId;
    model.photo =  this.selectedPhoto;
    
    if(this.isNewPhoto){
            this._infoTycoonApiService.addInspectionPhoto(model).subscribe(data => {
            this.selectedPhoto.uuid = data.photo.uuid;
            this.selectedPhoto.updatedBy = data.photo.updatedBy;
            this.selectedPhoto.updatedOn = data.photo.updatedOn;
            this.addPhoto();
            this.showToast("Item Photo was added succesfully");
            this.loading.destroy();
          }, error => {
            this.showToast("Something went wrong adding a Photo");
            this.loading.destroy();
          });

    }else{
      
       this._infoTycoonApiService.updateInspectionPhoto(model).subscribe(data => {
          this.selectedPhoto.uuid = data.photo.uuid;
          this.selectedPhoto.updatedBy = data.photo.updatedBy;
          this.selectedPhoto.updatedOn = data.photo.updatedOn;
          this.showToast("Item Photo was updated succesfully");
          this.loading.destroy();
        }, error => {
          this.showToast("Something went wrong updating a Photo");
          this.loading.destroy();
        });
    }
    
    this.newCaption = undefined;
    this.addingCaption = false;
  }
  
  saveCaption(caption: string){
    this.selectedPhoto.photoCaption = caption;
  }
  
  noCaption(){
    this.savePhoto();
  }
  
  acceptCaption(){
    this.saveCaption(this.newCaption);
    this.savePhoto();
  }

  cancelPhoto(){
    this.newCaption = undefined;
    this.addingCaption = false;
    this.selectedPhoto = null;
  }

 showToast(message) {
    let toast = this.toastController.create({
      message: message,
      duration: 3000,
      showCloseButton: true,
      closeButtonText: "x"
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }
    
}
