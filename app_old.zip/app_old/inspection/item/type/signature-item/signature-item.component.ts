import { Component, Input, OnInit } from '@angular/core';
import {ModalController} from 'ionic-angular';
import {DomSanitizationService} from '@angular/platform-browser'; 
import {SignatureModal} from './signature-modal.component';
import { Item } from '../../../shared/index';

@Component({
  selector: 'signature-item',
  templateUrl: 'build/inspection/item/type/signature-item/signature-item.component.html'
})
export class SignatureItemComponent implements OnInit {
  @Input() item:Item;

  constructor(private _DomSanitizationService: DomSanitizationService,
              private modalController: ModalController) {

  }
  
  ngOnInit() {
    this.item.extraData = this.item.extraData ? 'data:image/jpeg;base64,' + this.item.extraData : '';
  }

  showModal() {
    let signature: string = this.item.extraData;
    let modal = this.modalController.create(SignatureModal, { signature: signature });
    modal.onDidDismiss(data => {
      if(data)
        this.item.extraData = data
    });
    modal.present();
  }

}