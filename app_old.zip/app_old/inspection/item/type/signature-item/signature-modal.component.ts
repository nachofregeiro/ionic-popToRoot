import { Component, Input, ViewChild, ElementRef, NgZone } from '@angular/core';
import { ViewController, NavParams } from 'ionic-angular';

declare var SignaturePad;

@Component({
  templateUrl: 'build/inspection/item/type/signature-item/signature-modal.component.html'
})
export class SignatureModal {
  signaturePad: any;
  viewCtrl: ViewController;
  signature: any;
  width: number;
  height: number;

  @ViewChild('signatureCanvas') canvas: ElementRef;

  constructor(viewCtrl: ViewController, params: NavParams, ngZone: NgZone) {
    this.viewCtrl = viewCtrl;
    this.signature = params.get('signature');

    window.onresize = (e) => {
      ngZone.run(() => {
        this.loadSignature();
      });
    };
  }

  resizeCanvas() {
    let dimension = this.calculateCanvasDimension();

    this.width = dimension.width;
    this.height = dimension.height;

    let canvas = this.canvas.nativeElement;
    canvas.width =  dimension.width;
    canvas.height = dimension.height;

    this.signaturePad.clear();

    var image = new Image();
    image.src = this.signature;
    image.onload = this.loadImage(this.calculateCanvasDimension, image, canvas); 
    this.signaturePad._isEmpty = false;
  }

  ngAfterViewInit() {
    this.signaturePad = new SignaturePad(this.canvas.nativeElement);
    this.loadSignature();
  }

  loadSignature() {
    this.resizeCanvas();
  }
  clearCanvas = function () {
    this.signaturePad.clear();
  }

  cancel = function () {
    this.viewCtrl.dismiss();
  }

  saveCanvas = function () {
    let sigImg: any = undefined;
    var points = this.signaturePad.points;
    if (points && points.length > 0) {
      sigImg = this.signaturePad.toDataURL();
      this.viewCtrl.dismiss(sigImg);
    }
  }

  calculateCanvasDimension() : any {
      let width = window.screen.width > 400 ? 400 : window.screen.width;
      let height = width / 2;

      return { width: width, height: height};
  };

  loadImage(calculateCanvasDimension, image, canvas) : any {
      let dimension = calculateCanvasDimension();

      canvas.getContext("2d").drawImage(image, 0, 0, dimension.width, dimension.height);
  };
}
