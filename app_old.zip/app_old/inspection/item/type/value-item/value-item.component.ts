import { Component, Input, OnInit } from '@angular/core';
import { Item, ActionTypeEnum, Option } from '../../../shared/index';

@Component({
  selector: 'value-item',
  templateUrl: 'build/inspection/item/type/value-item/value-item.component.html'
})
export class ValueItemComponent implements OnInit {
  typeEnum = ActionTypeEnum;
  @Input() item: Item;
  options: Array<Option>;
  option: Option;


  ngOnInit() {
    this.options = new Array<Option>();
    for (let i = 1; i < 5; i++) {
      let itemValue = this.item["action" + i + "Caption"];
      if (itemValue) {
        this.option = new Option();
        this.option.key = i;
        this.option.value = itemValue;
        this.option.selected = this.item.defaultValue == i;
        this.options.push(this.option);
      }
    }
  }

  selectOption(option) {
    this.options.forEach(x => {
      x.selected = false;
    });
    option.selected = true;
    this.item.actionValue = option.key;
  }
}