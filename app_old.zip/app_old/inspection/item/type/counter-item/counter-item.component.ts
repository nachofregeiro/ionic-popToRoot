import { Component, Input } from '@angular/core';
import { Item } from '../../../shared/index';

@Component({
  selector: 'counter-item',
  templateUrl: 'build/inspection/item/type/counter-item/counter-item.component.html'
})
export class CounterItemComponent {
  @Input() item:Item;
  @Input() minValue:number;
  @Input() maxValue:number;
  
  increase(){
    let newValue = isNaN(this.item.counterValue) ? 0 : (this.item.counterValue + 1);
    
    if(newValue <= this.maxValue)
        this.item.counterValue = newValue;     
  }
  
  decrease(){
    let newValue = isNaN(this.item.counterValue) ? 0 : (this.item.counterValue - 1);

    if(newValue >= this.minValue)
        this.item.counterValue = newValue;
  }
}
