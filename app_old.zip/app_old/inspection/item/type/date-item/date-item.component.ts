import { Component, Input } from '@angular/core';
import { Item } from '../../../shared/index';

@Component({
  selector: 'date-item',
  templateUrl: 'build/inspection/item/type/date-item/date-item.component.html'
})
export class DateItemComponent {
  @Input() item:Item;
  
  
}
