import { Modal, NavController, Page, Loading, LoadingController, 
  ViewController, NavParams, ToastController, AlertController} from 'ionic-angular';
import { Component, Input, OnInit} from '@angular/core';
import { InfoTycoonApiService, DateTimeService } from '../../../shared/index';
import { Item, Comment } from '../../shared/index';

@Component({
  templateUrl: 'build/inspection/item/comments/item-comments.component.html'
})

export class ItemsComments {
  item: Item;
  loading: Loading;
  selectedComment: Comment;
  editedComment: string;
  showSaveAndClose: boolean;
  inspectionId: number;
  dateTimeService: DateTimeService

  constructor(private viewCtrl: ViewController, 
              private _infoTycoonApiService: InfoTycoonApiService, 
              private _dateTimeService: DateTimeService,
              params: NavParams, 
              private nav: NavController,
              private loadingController: LoadingController,
              private toastController: ToastController,
              private alertController: AlertController) {
    this.item = params.get('item');
    this.dateTimeService = _dateTimeService;
  }

  ngOnInit() {
    this.editedComment = "";
  }

  showLoading() {
    this.loading = this.loadingController.create({
      content: "Please wait..."
    });
    this.loading.present();
  }

  showNewComment() {
    this.showSaveAndClose = true;
    this.selectedComment = true;
  }

  done() {
    this.viewCtrl.dismiss();
  }

  save() {
    this.showLoading();
    if (this.editedComment != undefined && this.editedComment != "") {
      var data = {
        inspectionInteriorItemId: this.item.itemId,
        comment: { comments: this.editedComment },
        inspectionId: this._infoTycoonApiService._inspectionId
      };
      this.editedComment = "";
    }

    this._infoTycoonApiService.addInspectionInteriorItemComment(data).subscribe(data => {
      this.item.comments.push({ uUID: data["uuid"], comments: data["comments"], updatedBy: data["updatedBy"], updatedOn: data["updatedOn"] });
      this.item.commentsCount = this.item.comments.length;
      this.cleanComment();
      this.showToast("Item comment was added succesfully");
      this.loading.destroy();
    }, error => {
      this.showToast("Something went wrong adding a comment");
      this.loading.destroy();
    });


  }

  cleanComment() {
    this.showSaveAndClose = false;
    this.selectedComment = undefined;
    this.editedComment = undefined;
  }

  itemHasComments() {
    if (this.item.comments == undefined)
      return false;
    else
      return this.item.comments.length != 0
  }

  showToast(message) {
    let toast = this.toastController.create({
      message: message,
      duration: 3000,
      showCloseButton: true,
      closeButtonText: "x"
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  updateComments() {
    if (this.editedComment == undefined || this.editedComment == "")
      this.showToast("Comment should not be empty");
    if (this.editedComment.length > 1024 )
      this.showToast("Maximum length is 1024 characters");
    else {
      if (this.selectedComment == undefined || this.selectedComment == true)
        this.save();
      else
        this.update();
    }
  }

  update() {
    this.selectedComment.comments = this.editedComment;
    var data = {
      inspectionInteriorItemId: this.item.itemId,
      comment: this.selectedComment,
      inspectionId: this._infoTycoonApiService._inspectionId
    };

    this.showLoading();
    this._infoTycoonApiService.updateInspectionInteriorItemComment(data).subscribe(data => {
      this.selectedComment.updatedBy = data["updatedBy"];
      this.selectedComment.updatedOn = data["updatedOn"];
      this.cleanComment();
      this.showToast("Item comment was updated succesfully");
      this.loading.destroy();
    }, error => {
      this.showToast("Something went wrong updating a comment");
      this.loading.destroy();
    });

  }

  cancelComment() {
    this.selectedComment = undefined;
    this.showSaveAndClose = false;
    this.editedComment = undefined;
    if (this.item.comments == undefined || this.item.comments.length == 0)
      this.viewCtrl.dismiss();
  }

  editComment(comment) {
    this.showSaveAndClose = true;
    this.selectedComment = comment;
    this.editedComment = this.selectedComment.comments;
  }

  delete(comment) {
    let confirm = this.alertController.create({
      title: 'Delete Comment',
      message: 'Do you want to delete this comment?',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            console.log('Delete comment ' + comment);
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Cancel delete comment');
          }
        }
      ]
    });
    confirm.present();
  }
}
