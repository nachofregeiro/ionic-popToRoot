import { Component, Input, OnInit } from '@angular/core';
import { ModalController, NavController, ViewController, AlertController, Loading, LoadingController, ToastController } from 'ionic-angular';

import { Item, InspectionItem, MeasuringUnit } from '../shared/index';
import { ValueItemComponent, CounterItemComponent, DateItemComponent, SignatureItemComponent } from './type/index';
import { ActionTypeEnum, MeasuringUnitEnum } from '../shared/index';
import { ItemsComments } from './comments/index';
import { ItemPhotosComponent } from './photos/item-photos.component';
import { InfoTycoonApiService } from '../../shared/index';

@Component({
  selector: 'inspection-item',
  templateUrl: 'build/inspection/item/item.component.html',
  directives: [ValueItemComponent, CounterItemComponent, DateItemComponent, SignatureItemComponent]
})
export class ItemComponent implements OnInit {
  @Input() item: Item;
  @Input() measuringUnits: Array<MeasuringUnit>;
  @Input() inspectionItem: InspectionItem;
  
  loading: Loading;
  
  actionTypeEnum = ActionTypeEnum;
  
  constructor(private nav: NavController, 
              private _infoTycoonApiService: InfoTycoonApiService,
              private alertController: AlertController,
              private loadingController: LoadingController,
              private toastController: ToastController,
              private modalController: ModalController) { }

  ngOnInit() {
    this.inspectionItem = new InspectionItem(this.item);
  }

  isActionValue() {
    return this.item.actionTypeId == ActionTypeEnum.ActionValue ||
      this.item.actionTypeId == ActionTypeEnum.Status ||
      this.item.actionTypeId == ActionTypeEnum.PassFail
  }

  canViewPhotos() {
    return this.item.actionTypeId != ActionTypeEnum.Signature;
  }

  canViewComments() {
    return this.item.actionTypeId != ActionTypeEnum.Signature;
  }

  showQuantity() {
    return this.item.actionTypeId == ActionTypeEnum.ActionValue ||
      this.item.actionTypeId == ActionTypeEnum.Status ||
      this.item.actionTypeId == ActionTypeEnum.PassFail
  }

  showUnitOfMeasure() {
    return this.item.actionTypeId == ActionTypeEnum.ActionValue ||
      this.item.actionTypeId == ActionTypeEnum.Counter ||
      this.item.actionTypeId == ActionTypeEnum.Status ||
      this.item.actionTypeId == ActionTypeEnum.PassFail
  }

  canEditUnitOfMeasure() {
    return this.item.actionTypeId == ActionTypeEnum.Status ||
      this.item.actionTypeId == ActionTypeEnum.PassFail
  }

  canEditQuantity() {
    return this.item.actionTypeId == ActionTypeEnum.ActionValue ||
      this.item.actionTypeId == ActionTypeEnum.Status ||
      this.item.actionTypeId == ActionTypeEnum.PassFail
  }

  showComments() {
    let modal = this.modalController.create(ItemsComments, { item: this.item });
    modal.present();
  }

  showPhotos() {
    let modal = this.modalController.create(ItemPhotosComponent, { item: this.item });
    modal.present();
  }
  
  formatQuantity() {
    if (!this.item.quantity) return;

    let quantity = parseInt(this.item.quantity.toString().replace(/\D/g, ''));
    this.item.quantity = isNaN(quantity) ? null : quantity;
  }

  confirmReset(item) {
    let confirm = this.alertController.create({
      title: 'Reset item',
      message: 'Do you want to reset ' + item.itemName + ' item?',
      buttons: [
        {
          text: 'OK',
          handler: () => {
              this.showLoading();
              this.resetItem();
            }
        },
            {
          text: 'Cancel',
          handler: () => {
            console.log('Cancel resetting');
          }
        }
      ]
    });
    
   confirm.present();
    
  }
  
  
  resetItem(){
      this._infoTycoonApiService.resetItem(this.item.itemId, this.item.actionTypeId).subscribe(data => {
            this.setItemDefaultValues();
            this.showToast("Item was reset succesfully");
            this.loading.destroy();
      }, error => {
            this.showToast("Something went wrong when resetting item");
            this.loading.destroy();
      });
  
  }
  
  setItemDefaultValues = function(){
          var stringValue = ActionTypeEnum[this.item.actionTypeId];
          var actionType = ActionTypeEnum[stringValue];

            switch (actionType)
            {
                case ActionTypeEnum.ActionValue:
                    this.item.actionValue = this.item.defaultValue ? this.item.defaultValue.toString() : null ;
                    this.item.measuringUnitId = this.item.measuringUnitId;
                    this.item.quantity = "0";
                    break;
                case ActionTypeEnum.Counter:
                    this.item.counterValue = null;
                    break;
                case ActionTypeEnum.Date:
                    this.item.dateValue = null;
                    break;
                case ActionTypeEnum.Status:
                case ActionTypeEnum.PassFail:
                    this.item.actionValue = null;
                    this.item.quantity = null;
                    this.item.measuringUnitId = MeasuringUnitEnum.Each;
                    
                    break;
                case ActionTypeEnum.Signature:
                    this.item.extraData = null;
                    break;
                default:
                    break;
            }
            
          this.item.photosCount = 0;
          this.item.commentsCount = 0;
                    
  };
  
  showLoading() {
    this.loading = this.loadingController.create({
      content: "Please wait..."
    });
    this.loading.present();
  }
  
  showToast(message) {
    let toast = this.toastController.create({
      message: message,
      duration: 3000,
      showCloseButton: true,
      closeButtonText: "x"
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }
}

