export enum ActionTypeEnum {
    ActionValue =1,
    Survey = 2,
    Counter = 3,
    Date = 4,
    PettyCash = 5,
    Status = 6,
    PassFail = 7,
    Signature = 8
}

export enum MeasuringUnitEnum {
    Each = 1,
    SqFeet = 2,
    LinearFeet = 3,
    Hours = 4,
    SqYards = 5,
    CubicYards = 6,
    SqInches = 7
}
