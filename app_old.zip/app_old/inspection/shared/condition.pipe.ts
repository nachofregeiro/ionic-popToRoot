import {Pipe} from '@angular/core';

@Pipe({
  name: 'ConditionPipe'
})
export class ConditionPipe {
  transform(value) {
    return value.filter(item => {
      return item.conditionId != 0;
    });
  }

}