import { ActionTypeEnum } from './inspection.enum';

export class Photo {
  inspectionPhotoId: number;
  inspectionItemId: number;
  url: string;
  thumbnailUrl: string;
  updatedBy: string;
  updatedOn: string;
  latitude: number;
  longitude: number;
  inspectionItemUUID: string;
  uuid: string;
  localFileName: string;
  photoCaption: string;
  imageData: string;
}

export interface Comment {
  uUID?: string;
  comments?: string;
  createdOn?: string;
  createdBy?: string;
  updatedOn?: string;
  updatedBy?: string;
  name?: string;
  itemId?: number;
  type?: string;
  buildingName?: string;
  phaseName?: string;
  siteAreaName?: string;
  unitName?: string;
  categoryId?: number;
  categoryName?: string;
  selected?: boolean;
  inspectionExteriorItemIssueCommentId?: number;
  inspectionInteriorItemCommentId?: number;  
}

export interface TriggerAndRequirePccRules {
  photoActionValue?: number[];	
  photoCounterGt?: number;	
  photoCounterLt?: number;	
  photoCounterEq?: number;	
  photoDateGt?: string;	
  photoDateLt?: string;	
  photoDateEq?: string;	
  captionActionValue?: number[];	
  captionCounterGt?: number;	
  captionCounterLt?: number;	
  captionCounterEq?: number;	
  captionDateGt?: string;	
  captionDateLt?: string;	
  captionDateEq?: string;	
  commentActionValue?: number[];	
  commentCounterGt?: number;	
  commentCounterLt?: number;	
  commentCounterEq?: number;	
  commentDateGt?: string;	
  commentDateLt?: string;	
  commentDateEq?: string;	
  serviceRequestActionValue?: number[];	
  serviceRequestCounterGt?: number;	
  serviceRequestCounterLt?: number;	
  serviceRequestCounterEq?: number;	
  serviceRequestDateGt?: string;	
  serviceRequestDateLt?: string;	
  serviceRequestDateEq?: string;	  
}

export class Option{
    key : number;
    value: string;
    selected : boolean;
}
export interface Item {
  mainCategoryId?: number;	
  mmainCategoryName?: string;	
  categoryId?: number;	
  categoryName?: string;	
  itemId?: number;	
  itemName?: string;	
  action1Caption?: string;	
  action2Caption?: string;	
  action3Caption?: string;	
  action4Caption?: string;	
  actionValue?: string;	
  defaultValue?: number;	
  quantity?: number;	
  actionTypeId?: number;	
  categorySortOrder?: number;	
  itemSortOrder?: number;	
  useSortOrder?: boolean;	
  action1EstCost?: number;	
  action2EstCost?: number;	
  action3EstCost?: number;	
  action4EstCost?: number;	
  estimatedCost?: number;	
  actualCost?: number;	
  isActionRequired?: boolean;	
  scoreValue?: number;	
  extraData?: string; 
  dateValue?: string;	
  counterValue?: number;	
  comments?: Comment[];
  photos?: Photo[];
  requirePccRules?: TriggerAndRequirePccRules;
  statusId?: number;	
  updatedBy?: string;	
  updatedOn?: string;	
  uuID?: string;	
  commentsCount?: number;	
  photosCount?: number;	
  issueUUID?: string;	
  issueTitle?: string;	
  inspectionExteriorItemIssueId?: number;	
  buildingExteriorUnitExteriorItemId?: number;	
  inspectionBuildingExteriorUnitId?: number;	
  inspectionSiteAreaUnitId?: number;	
  priorityId?: number;	
  inspectionInteriorItemId?: number;	
  inspectionExteriorItemId?: number;	
  inspectionItemId?: number;	
  siteAreaUnitExteriorItemId?: number;	
  siteAreaUnitId?: number;	
  completed?: number;	
  unitId?: number;	
  unitName?: string;	
  exteriorCategoryId?: number;	
  interiorItemId?: number;	
  exteriorItemId?: number;	
  maxScore?: number;	
  phaseId?: number;	
  phaseName?: string;	
  buildingId?: number;	
  buildingName?: string;	
  measuringUnitId?: number;	
  measuringUnitName: string;
  latitude?: number;	
  longitude?: number;	
  csiCodeId?: number;	
  itemCsiCodeId?: number;	

  isCompleted: boolean;
}

export class InspectionItem {
  item: Item;

  constructor(private _item: Item) { 
    this.item = _item;
  }

  hasValue (_value: any) {
    return _value != undefined && 
          _value != "" && 
          _value != null;
  }

  isCompleted() {
    if (this.item != undefined) {
      let _completed:boolean = true;  
      let itemTypeId = this.item.actionTypeId;
      switch(itemTypeId) {
        case ActionTypeEnum.ActionValue:
        case ActionTypeEnum.Status:
        case ActionTypeEnum.PassFail:
          _completed = (this.hasValue(this.item.actionValue));
          break;
        case ActionTypeEnum.Counter:
          _completed = (this.hasValue(this.item.counterValue) || this.item.counterValue === 0);
          break;
        case ActionTypeEnum.Date:
          _completed = (this.hasValue(this.item.dateValue));
          break;
        case ActionTypeEnum.Signature:
          _completed = (this.hasValue(this.item.extraData));
          break;
      }

      this.item.isCompleted = _completed;
      return _completed;
    }
    return false;
  }
}

export interface Unit {
  unitId?: number;	
  unitName?: string;	
  phaseId?: number;	
  phaseName?: string;	
  buildingId?: number;	
  buildingName?: string;	
  statusId?: number;	
  statusName?: string;	
  totalItems?: number;	
  completedItems?: number;	
  categoryId?: number;	
  categoryName?: string;	
}

export interface ItemsDetail {
  inspectionId: number;
  unit: Unit;
  categories?: Category[];  
  items?: Item[];  
}

export interface MeasuringUnit
{
  measuringUnitId?: number;
  name?: string;
}

export interface InspectionUnitStatusType
{
  inspectionUnitStatusTypeId?: number;
  name?: string;
}

export interface InspectionUnitStatusReasonType
{
  ispectionUnitStatusReasonTypeId?: number;
  name?: string;
}

export interface CsiCode
{
  csiCodeId?: number;
  code?: string;
  name?: string;
  level1?: string;
  level2?: string;
  level3?: string;
  level4?: string;
}

export interface LookupDetails {
  measuringUnits: MeasuringUnit[];  
  inspectionUnitStatusTypes: InspectionUnitStatusType[];  
  inspectionUnitStatusReasonType: InspectionUnitStatusReasonType[];  
  csiCode: CsiCode[];  
}


export interface Category {
  categoryId?: number;	
  categoryName?: string;
  categorySortOrder?: number;	  
  items: Item[];
  isCompleted: boolean;
}

export class InspectionCategory {
    category: Category;

  constructor(private _category: Category) { 
    this.category = _category;
  }

  isCompleted() {
    if (this.category != undefined) {
      let _completed: boolean = true;

      let _items = this.category.items;
      _items.forEach((itm: Item) => {
        let inspectionItem = new InspectionItem(itm);
        _completed = _completed && inspectionItem.isCompleted();
      });

      this.category.isCompleted = _completed;
      return _completed;
    }
    return false;
  }

  getCompletedItems() {
    let _completed: number = 0;

    if (this.category != undefined) {
      let _items = this.category.items;
      _items.forEach((itm: Item) => {
        let inspectionItem = new InspectionItem(itm);
        _completed += inspectionItem.isCompleted() ? 1 : 0;
      });
    }
    return _completed;
  }
}

export interface ItemTypeOption{
	value:number;
	description:string;
}

export interface ItemCommentsModel
{
   inspectionId ?: number;
   inspectionInteriorItemId ?: number;
   comment: Comment
}

export class ItemPhoto
{
   inspectionId: number;
   itemId: number;
   photo: Photo
}