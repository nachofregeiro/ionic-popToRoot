import { Component, enableProdMode, provide } from '@angular/core';
import { ionicBootstrap, Platform } from 'ionic-angular';
import { StatusBar } from 'ionic-native';
import { HTTP_PROVIDERS, XHRBackend, RequestOptions, ConnectionBackend, Http } from '@angular/http';

import { LoginComponent } from './login/index';
import { HomeComponent } from './home/index';
import { PropertyComponent } from './property/index';
import { SettingsService } from './config/index';
import { InfoTycoonApiService, HttpRequest, DateTimeService } from './shared/index';

@Component({
  template: '<custom-router-outlet></custom-router-outlet><ion-nav [root]="rootPage"></ion-nav>'
})
export class ResidentApp {
  rootPage: any;
  constructor(platform: Platform, settings: SettingsService) {
    this.rootPage = LoginComponent;

    platform.ready().then(() => {
      StatusBar.styleDefault();    
      settings.isWebBrowser = window && window.hasOwnProperty('cordova') && window['cordova'].platformId === "browser";        
    });
  }
}

enableProdMode();

ionicBootstrap(ResidentApp, [HTTP_PROVIDERS, provide(Http, {
      useFactory: (backend: XHRBackend, defaultOptions: RequestOptions) => new HttpRequest(backend, defaultOptions),
      deps: [XHRBackend, RequestOptions]
  }), SettingsService,InfoTycoonApiService, DateTimeService ], {
  tabbarPlacement: 'bottom',
  mode: 'md',
  platforms: {
      ios: {
        statusbarPadding: false
      }
  }
});