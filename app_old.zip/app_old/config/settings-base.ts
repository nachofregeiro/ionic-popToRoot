export class SettingsBase {
  public apiUrl: string;
  public isWebBrowser: boolean
  constructor() {
     this.apiUrl = '';
     this.isWebBrowser = false;
  }
}