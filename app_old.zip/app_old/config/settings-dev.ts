import { Injectable } from "@angular/core";

import { SettingsBase } from "./settings-base";
 
@Injectable()
export class SettingsService extends SettingsBase {
  constructor() {
    super();
    this.apiUrl = 'https://mobileresident.infotycoon.com';
  }
}