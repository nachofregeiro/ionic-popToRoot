import { Injectable } from "@angular/core";

import { SettingsBase } from "./settings-base";
 
@Injectable()
export class SettingsService extends SettingsBase {
  constructor() {
    super();
    this.apiUrl = 'https://api.infotycoon.local';
  }
}