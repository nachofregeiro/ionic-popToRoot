import { NavController } from 'ionic-angular';
import { Component } from '@angular/core';

import { InspectionComponent } from '../inspection/index';
import { PropertyComponent } from '../property/index';

import { InfoTycoonApiService, InstrucionsMessageComponent } from '../shared/index';
@Component({
  templateUrl: 'build/home/home.component.html',
  directives: [InstrucionsMessageComponent]
})
export class HomeComponent {
  inspectionId: number;
  unitId: number;

  constructor(private nav: NavController, 
              private _infoTycoonApiService: InfoTycoonApiService) {

  }

  start() {    
     this.nav.push(InspectionComponent);
  }

  goBack(){
    this.nav.pop();
  }
}
