export * from './property.component';
export * from './property.model';

