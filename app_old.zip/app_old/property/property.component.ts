import { LoadingController, Loading, NavController } from 'ionic-angular';
import { Component, OnInit } from '@angular/core';

import { InfoTycoonApiService, Accordion, AccordionGroup } from '../shared/index';
import { Property } from './property.model';
import { PropertyInspectionItemComponent } from './property-inspection-item/index';

@Component({
  templateUrl: 'build/property/property.component.html',
  directives: [Accordion, AccordionGroup, PropertyInspectionItemComponent]
})
export class PropertyComponent implements OnInit {
  loading: Loading;
  inspectionId: number;
  unitId: number;
  property: Property;
  dataLoaded: boolean;

  constructor(private nav: NavController,
              private _infoTycoonApiService: InfoTycoonApiService,
              private loadingController: LoadingController) {

    this.property = new Property();
  }

  ngOnInit() {
    this.loading = this.loadingController.create({
      content: "Please wait..."
    });

    this.loading.present();
    this.loadData("123456789", "454");
  }

  reload(unitExternalId, propertyExternalId) {
    this.loadData(unitExternalId, propertyExternalId);
  }

  loadData(unitExternalId, propertyExternalId) {
    this._infoTycoonApiService._unitExternalId = unitExternalId;
    this._infoTycoonApiService._propertyExternalId = propertyExternalId;
      this._infoTycoonApiService.getProperty()
        .subscribe(data => {
          this.property = data;
          this.dataLoaded = true;
          this._infoTycoonApiService._unitId = data.unitId;
          this.loading.dismiss();
        }, error => {
          this.loading.dismiss();
        });
  }

  popToRoot() {
    setTimeout(() => {
      this.nav.popToRoot();
    }, 100);
  }
}
