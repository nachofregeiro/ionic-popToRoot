import { Component, Input, OnInit } from '@angular/core';
import { NavController, ViewController} from 'ionic-angular';

import { PropertyInspection } from '../property.model';
import { HomeComponent } from '../../home/index';
import { InfoTycoonApiService, DateTimeService } from '../../shared/index';

@Component({
  selector: 'property-inspection-item',
  templateUrl: 'build/property/property-inspection-item/property-inspection-item.component.html'
})
export class PropertyInspectionItemComponent implements OnInit {
  @Input() item: PropertyInspection;
  showReportLink: boolean;
  canViewDetail: boolean;
  dateTimeService: DateTimeService;

  constructor(private nav: NavController, 
              private _infoTycoonApiService: InfoTycoonApiService,
              private _dateTimeService: DateTimeService) {
    this.dateTimeService = _dateTimeService;
  }

  ngOnInit() {
    this.showReportLink = this.item.status == "Completed";
    this.canViewDetail = this.item.status != "Completed"
  }

  viewInspectionDetail() {
    if (!this.canViewDetail) return;
    this._infoTycoonApiService._inspectionId = this.item.inspectionId;
    this.nav.push(HomeComponent);
  };
}