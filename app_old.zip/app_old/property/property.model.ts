export class Property {
  constructor(){
    this.name = "";
    this.address = "";
    this.city = "";
    this.stateName = "";
    this.imageUrl = "";
    this.inspectionGroups = []; 
  }

  propertyId: number;
  name: string;
  address: string;
  city: string;
  stateName: string;
  imageUrl: string;
  unitId: number;
  inspectionGroups: PropertyInspectionGroup[]; 
}

export class PropertyInspectionGroup{
  name: string;
  inspections: PropertyInspection[];  
}
export class PropertyInspection {
  inspectionId: number;
  name: string;
  dueDate: string;
  dateCreated: string;
  inspectionType: string;
  inspectionSubtype: string;
  status: string;
}