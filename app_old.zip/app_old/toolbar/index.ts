import { Component } from '@angular/core';

import { ionicBootstrap } from 'ionic-angular';


@Component({
  templateUrl: 'build/toolbar/main.html'
})
export class ApiDemoPage {
  demo = "Toolbar";
  favorites = "recent";
  apps = "free";
}
