import { Page, NavController, ToastController, Loading, LoadingController } from 'ionic-angular';
import { Component, OnInit } from '@angular/core';

import { HomeComponent } from '../home/index';
import { PropertyComponent } from '../property/index';
import { InfoTycoonApiService, InstrucionsMessageComponent } from '../shared/index';

@Component({
  templateUrl: 'build/login/login.component.html',
  directives: [InstrucionsMessageComponent]
})

export class LoginComponent implements OnInit {
  loading: Loading;
  username: string;
  password: string;

  constructor(private nav: NavController, 
              private _infoTycoonApiService: InfoTycoonApiService,
              private toastController: ToastController,
              private loadingController: LoadingController) {
      this.username = "fmolinuevo@velocitypartners.net";
      this.password = "test_123";
  }

  ngOnInit() {
    // var token_type = localStorage.getItem("token_type");
    // var access_token = localStorage.getItem("access_token");
        
    // if (token_type && access_token) {
    //   this.nav.push(PropertyComponent);
    // }
  }

  login() {
    this.loading = this.loadingController.create({
       content: "Please wait..."
    });

    this.loading.present();

    this._infoTycoonApiService.getToken(this.username, this.password)
      .subscribe(data => {
        console.log(data);
        if(data.ok){
            var token = data.json();
            localStorage.setItem("token_type", token.token_type);
            localStorage.setItem("access_token", token.access_token);
            // Navigate to home view
            this.loading.dismiss();
            //this.nav.push(PropertyComponent);
        } else {
            console.log("Wrong username or password.");
        }
        this.loading.dismiss();
      }, error => {
        this.loading.dismiss();
      });
      this.nav.push(PropertyComponent);
  }

  start() {    
    
  }
}