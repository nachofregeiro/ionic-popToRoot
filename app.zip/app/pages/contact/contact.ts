import {Component} from '@angular/core';
import {NavController} from 'ionic-angular';

import { AboutPage } from '../about/about';

@Component({
  templateUrl: 'build/pages/contact/contact.html'
})
export class ContactPage {
  constructor(private nav: NavController) {
  }

  ionViewDidEnter() {
    setTimeout(() => {
      this.nav.push(AboutPage);
    }, 1000);
  }
}
