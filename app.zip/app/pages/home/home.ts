import {Component, OnInit} from '@angular/core';
import {NavController} from 'ionic-angular';

import { ContactPage } from '../contact/contact';

@Component({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage implements OnInit {
  constructor(private nav: NavController) {
  
  }

  ngOnInit() {
    this.nav.push(ContactPage);
  }
  
  pushPage() {
    this.nav.push(ContactPage);
  }
}
