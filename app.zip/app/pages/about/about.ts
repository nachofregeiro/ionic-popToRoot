import {Component} from '@angular/core';
import {NavController} from 'ionic-angular';

@Component({
  templateUrl: 'build/pages/about/about.html'
})
export class AboutPage {
  constructor(private nav: NavController) {
  }

  ionViewDidEnter() {
    // setTimeout(() => {
    //   this.nav.popToRoot();
    // }, 1000);
  }

  popToRoot() {
    this.nav.popToRoot();
  }
}
